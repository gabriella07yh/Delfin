<?php
//configuracion: ajustar URL base segun el entorno

define('APP_NAME', 'directorio de revistas cientificas');
define('APP_URL',  '');
define('APP_ENV',  'development');

define('GEMINI_KEY',   'AQ.Ab8RN6L8tz5wtgCNyB4uCxyN0yIInKuKYzAIf0GIgW7HCp_Jtg');
define('GEMINI_MODEL', 'gemini-2.0-flash'); //gemini-3.5-flash

define('ITEMS_POR_PAGINA', 10);
